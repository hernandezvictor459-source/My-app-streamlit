# Proyecto de aplicación con IA: Masas Delicias del Caribe, S.R.L.

Propuesta para una aplicación inteligente de atención al cliente, ventas al por mayor y gestión de consultas comerciales.

## 1. Los problemas y usuarios de esta empresa

### ¿Qué problema resuelve?
La empresa necesita atender de manera rápida y organizada las consultas de sus clientes mayoristas sobre precios, descuentos por volumen, formas de pago, crédito comercial y pedidos. Una aplicación con inteligencia artificial puede responder estas preguntas automáticamente, ayudar a calcular cotizaciones y mejorar la atención al cliente.

### ¿Quién tiene el problema y cómo lo resuelve hoy?
- **Clientes mayoristas:** supermercados, restaurantes, cafeterías, distribuidores y negocios de alimentos que necesitan conocer los precios y las ofertas.
- **Personal de ventas:** debe responder repetidamente las mismas preguntas, preparar cotizaciones y explicar las condiciones comerciales.
- **Personal de cobros:** necesita recordar a los clientes sus pagos pendientes de manera amable y profesional.

Actualmente, estas tareas pueden realizarse por WhatsApp, llamadas telefónicas o mensajes manuales. Esto puede provocar demoras, errores en los cálculos y pérdida de oportunidades de venta.

### ¿Qué parte resuelve la IA?
La IA funcionará como un asistente comercial virtual que podrá:
- Responder preguntas sobre productos, precios y descuentos.
- Calcular cotizaciones según la cantidad solicitada y la forma de pago.
- Explicar las condiciones de compra al contado y a crédito.
- Redactar recordatorios de pago amables.
- Orientar al cliente sobre las ofertas disponibles.

La IA no aprobará créditos, confirmará pagos ni modificará precios por su cuenta. Para esas acciones se necesitará la validación de la empresa.

---

## 2. ¿Qué hace la aplicación?
La aplicación, llamada **Asistente Comercial Masas del Caribe**, será una herramienta web sencilla donde los clientes podrán escribir sus preguntas y recibir respuestas inmediatas.

Su funcionamiento será el siguiente:
1. El cliente entra a la aplicación.
2. Escribe lo que necesita, por ejemplo, el precio de 250 paquetes de masas.
3. La aplicación identifica la consulta y utiliza la lista de precios comercial establecida.
4. Calcula el precio por volumen y aplica el descuento correspondiente a la forma de pago.
5. Presenta el total, el ahorro y las condiciones comerciales.

También permitirá consultar las ofertas y generar mensajes de recordatorio para clientes con pagos atrasados.

---

## 3. Entradas y salidas

| El usuario da… | La app devuelve… | Ejemplo |
| :--- | :--- | :--- |
| Cantidad de paquetes | Precio por paquete y total | 100 paquetes: RD$ 10,500 antes del descuento por pago |
| Cantidad y forma de pago | Cotización con el descuento correspondiente | 100 paquetes al contado: RD$ 10,185 |
| Consulta sobre pagos atrasados | Mensaje cordial de recordatorio | Un mensaje para solicitar la regularización del balance sin perder la buena relación comercial |

---

## 4. ¿Qué pieza de IA utiliza?
Se propone utilizar la API de un modelo de lenguaje (LLM), como Gemini, para comprender las preguntas de los clientes y redactar respuestas naturales.

### Opción propuesta: Gemini API
Modelo de lenguaje para comprender consultas y generar respuestas en español.

**¿Por qué elegirla?**
- Permite integrar un asistente conversacional en una aplicación web.
- Puede comprender preguntas escritas de diferentes maneras.
- Facilita la generación de mensajes comerciales amables y profesionales.
- Puede probarse con una cuota gratuita, si el modelo elegido y la cuenta cumplen las condiciones vigentes.

**¿Por qué no utilizar únicamente un modelo de Hugging Face?**
También es una opción válida, pero algunos modelos requieren más configuración o recursos para ejecutarse. Para un primer prototipo, una API conversacional puede simplificar la integración.

*Importante: la disponibilidad de la capa gratuita depende del modelo, la cuota y las condiciones vigentes del proveedor. Los cálculos de precios se harán mediante reglas programadas, no se dejarán a criterio de la IA.*

### Tecnologías complementarias
- **Streamlit:** para crear la aplicación web.
- **Gemini API:** para comprender preguntas y redactar respuestas.
- **Python:** para calcular precios, descuentos y totales.
- **GitHub:** para guardar el código del proyecto.
- **Streamlit Community Cloud:** como opción de despliegue gratuito, sujeto a sus condiciones vigentes.

---

## 5. Restricciones del proyecto

| Restricción | Cómo se cumplirá |
| :--- | :--- |
| **Coste cero** | Se utilizarán las cuotas gratuitas disponibles y un servicio de alojamiento gratuito. No se garantiza coste cero si se exceden los límites del proveedor. |
| **Seguridad de la API** | La clave se almacenará en los secretos de la aplicación, nunca directamente en el código. |
| **Privacidad** | Se utilizarán datos ficticios, sin nombres, teléfonos, direcciones ni balances reales de clientes. |
| **Lenguaje sencillo** | La aplicación responderá en español claro, con explicaciones fáciles de entender. |
| **Precios realistas** | Se utilizará una lista comercial fija, con precios en pesos dominicanos (RD$), descuentos y condiciones definidas. |
| **Control comercial** | La IA no podrá inventar precios, autorizar créditos ni confirmar transacciones. |

### Lista de precios que utilizará la aplicación
Los siguientes precios son ficticios y corresponden a la empresa creada. Se utilizarán como referencia oficial dentro del prototipo.

*Presentación: paquete de 12 unidades de masas para empanadas.*

- **1–49 paquetes:** RD$ 120.00 / paquete
- **50–99 paquetes:** RD$ 112.00 / paquete
- **100–249 paquetes:** RD$ 105.00 / paquete
- **250–499 paquetes:** RD$ 98.00 / paquete
- **500–999 paquetes:** RD$ 92.00 / paquete
- **1,000 o más:** RD$ 85.00 / paquete

**Descuentos por forma de pago:**
- **Al contado:** 3% adicional sobre el precio por volumen.
- **A crédito aprobado:** 1% adicional sobre el precio por volumen.
- Los descuentos no se acumularán con otras promociones salvo autorización.
- Los precios no incluyen impuestos ni transporte.

*Ejemplo: si un cliente solicita 250 paquetes, el precio por volumen será RD$ 98 por paquete. El subtotal será RD$ 24,500; al contado, con el descuento adicional del 3%, pagará RD$ 23,765, antes de impuestos y transporte.*

---

## 6. Criterios de aceptación
La aplicación se aprobará si responde correctamente a las siguientes entradas y produce los resultados esperados.

| Entrada | Resultado esperado |
| :--- | :--- |
| **1. Cliente solicita 50 paquetes** | La app devuelve RD$ 112 por paquete y RD$ 5,600 de subtotal. |
| **2. Cliente solicita 100 paquetes al contado** | La app calcula RD$ 10,500 menos 3% y devuelve RD$ 10,185. |
| **3. Cliente solicita 250 paquetes a crédito aprobado** | La app calcula RD$ 24,500 menos 1% y devuelve RD$ 24,255. |
| **4. Cliente pregunta por el precio de 500 paquetes** | La app informa RD$ 92 por paquete y RD$ 46,000 de subtotal. |
| **5. Cliente pregunta por el descuento al contado** | La app explica que recibe un 3% adicional sobre el precio por volumen. |
| **6. Cliente pregunta por el descuento a crédito** | La app explica que recibe un 1% adicional si tiene el crédito aprobado. |
| **7. Usuario solicita un recordatorio de pago** | La app redacta un mensaje cordial, comprensivo y profesional. |
| **8. Cliente pregunta si la IA puede aprobar su crédito** | La app aclara que la aprobación corresponde al personal autorizado de la empresa. |
| **9. Cliente solicita un precio para una cantidad no especificada** | La app aplica el tramo de volumen correspondiente o solicita aclaración si faltan datos. |

### Resultado final esperado
Al finalizar el proyecto, se tendrá una aplicación web funcional que permita a Masas Delicias del Caribe, S.R.L. automatizar consultas comerciales, calcular cotizaciones mayoristas, informar sobre descuentos y generar mensajes de atención al cliente, utilizando inteligencia artificial de forma controlada, segura y económica.
