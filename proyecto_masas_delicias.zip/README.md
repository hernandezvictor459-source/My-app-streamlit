# README.md - Masas Delicias del Caribe, S.R.L.

# Masas Delicias del Caribe, S.R.L.

**Nombre comercial:** Masas Delicias del Caribe, S.R.L.
**Actividad comercial:** Fabricación y distribución al por mayor de masas para empanadas
**Ubicación:** Santo Domingo, República Dominicana
**Tipo de empresa:** Pequeña empresa manufacturera de alimentos
**Sitio web:** anko.com.tw

---

## 1. Visión
Ser una empresa líder en la fabricación y distribución al por mayor de masas para empanadas en la República Dominicana, reconocida por la calidad de sus productos, la innovación y la confianza de sus clientes comerciales.

## 2. Misión
Fabricar masas para empanadas de alta calidad, utilizando ingredientes seleccionados y procesos higiénicos que garanticen productos frescos, seguros y uniformes, satisfaciendo las necesidades de supermercados, restaurantes, cafeterías, distribuidores y otros negocios de alimentos.

## 3. Objetivo general
Producir y distribuir masas para empanadas al por mayor, ofreciendo precios competitivos, calidad constante y entregas oportunas, con el propósito de establecer relaciones comerciales duraderas y lograr un crecimiento sostenible en el mercado nacional.

### Objetivos específicos
- **Calidad**: Garantizar que las masas cumplan con los estándares de higiene e inocuidad alimentaria.
- **Distribución**: Abastecer de manera eficiente a supermercados, restaurantes, cafeterías y distribuidores.
- **Crecimiento**: Ampliar progresivamente la cartera de clientes mayoristas en diferentes provincias del país.
- **Rentabilidad**: Optimizar los costos de producción para ofrecer precios competitivos y mantener la rentabilidad del negocio.

---

## 4. Alcance de la empresa
Masas Delicias del Caribe se enfocará en la fabricación y venta al por mayor, sin centrarse en la venta directa al consumidor final. Su modelo de negocio estará dirigido a empresas y comercios que necesiten comprar masas para empanadas en grandes cantidades.

---

## 5. Lista de precios ficticia al por mayor

### Precios base
| Cantidad de paquetes | Precio por paquete | Total de compra |
|----------------------|--------------------|-----------------|
| 1-49                 | RD$ 120.00         | Desde RD$ 120   |
| 50-99                | RD$ 112.00         | Desde RD$ 5,600 |
| 100-249              | RD$ 105.00         | Desde RD$ 10,500|
| 250-499              | RD$ 98.00          | Desde RD$ 24,500|
| 500-999              | RD$ 92.00          | Desde RD$ 46,000|
| 1,000 o más          | RD$ 85.00          | Desde RD$ 85,000|

---

### Ofertas por volumen
| Volumen de compra | Oferta comercial |
|-------------------|------------------|
| 50 paquetes       | 6.7% de descuento |
| 100 paquetes      | 12.5% de descuento |
| 250 paquetes      | 18.3% de descuento |
| 500 paquetes      | 23.3% de descuento |
| 1,000 paquetes    | 29.2% de descuento |

---

### Descuentos especiales según forma de pago
- **Clientes al contado**: 3% adicional.
- **Clientes con crédito aprobado**: 1% adicional.

---

### Tabla comparativa de precios finales
| Cantidad | Precio base | Al contado (3%) | A crédito (1%) |
|----------|-------------|-----------------|----------------|
| 50       | RD$ 112.00  | RD$ 108.64      | RD$ 110.88     |
| 100      | RD$ 105.00  | RD$ 101.85      | RD$ 103.95     |
| 250      | RD$ 98.00   | RD$ 95.06       | RD$ 97.02      |
| 500      | RD$ 92.00   | RD$ 89.24       | RD$ 91.08      |
| 1,000    | RD$ 85.00   | RD$ 82.45       | RD$ 84.15      |

---

### Ejemplo de compra mayorista
**Pedido de 500 paquetes**
- Precio regular por volumen: RD$ 46,000.00
- Descuento adicional al contado (3%): - RD$ 1,380.00
- **Total pagando al contado: RD$ 44,620.00**

---

## 6. Política comercial sugerida
- **Compras por volumen**: El precio se determina según la cantidad total de paquetes del pedido.
- **Pago al contado**: Se aplica un 3% adicional de descuento.
- **Ventas a crédito**: Se aplica un 1% adicional a clientes previamente evaluados y aprobados.
- **Pedidos especiales**: Las compras superiores a 1,000 paquetes pueden recibir cotizaciones personalizadas.
- **Acumulación de descuentos**: Los descuentos por volumen y forma de pago se pueden combinar.
- **Vigencia**: Los precios son ficticios y sujetos a revisión según costos de producción, empaque y distribución.
